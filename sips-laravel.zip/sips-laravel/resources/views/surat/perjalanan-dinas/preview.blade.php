@extends('layouts.app')

@section('page-title', 'Preview Surat')

@section('content')
<div class="preview-card">
    <h3>Nomor Surat: {{ $surat->nomor_surat }}</h3>
    <p><strong>Nomor SPPD:</strong> {{ $surat->nomor_spd }}</p>
    <p><strong>Materi:</strong> {{ $surat->materi }}</p>
    <p><strong>Tanggal:</strong> {{ $surat->tanggal_mulai->format('d/m/Y') }} - {{ $surat->tanggal_selesai->format('d/m/Y') }}</p>
    <p><strong>Kota Tujuan:</strong> {{ implode(', ', $surat->kota_tujuan ?? []) }}</p>
    <p><strong>Penandatangan:</strong> {{ $surat->nama_ttd }} ({{ $surat->jabatan_ttd }})</p>

    <div class="preview-actions">
        <a href="{{ route('surat.perjalanan-dinas.surat-tugas', $surat) }}" class="btn-primary">
            Download Surat Tugas (.docx)
        </a>
        <a href="{{ route('surat.perjalanan-dinas.sppd', $surat) }}" class="btn-secondary">
            Download SPPD (.docx)
        </a>
    </div>
</div>
@endsection
