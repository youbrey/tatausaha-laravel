@extends('layouts.app')

@section('page-title', 'Buat Surat Tugas / SPPD')

@section('content')
<form method="POST" action="{{ route('surat.perjalanan-dinas.store') }}" class="sips-form">
    @csrf

    <div class="form-group">
        <label>Jenis Surat</label>
        <select name="jenis_surat" required>
            @foreach (config('sips.jenis_surat') as $key => $label)
                @continue(!str_starts_with($key, 'PERJALANAN_DINAS'))
                <option value="{{ $key }}">{{ $label }}</option>
            @endforeach
        </select>
    </div>

    <div class="form-group">
        <label>Dasar Surat Tugas</label>
        <textarea name="dasar_surat_tugas" rows="2"></textarea>
    </div>

    <div class="form-group">
        <label>Materi / Keperluan</label>
        <textarea name="materi" rows="2" required></textarea>
    </div>

    <div class="form-group">
        <label>Jenis Perjalanan</label>
        <input type="text" name="jenis_perjalanan" placeholder="Contoh: Dalam Daerah / Luar Daerah">
    </div>

    <div class="form-row">
        <div class="form-group">
            <label>Tanggal Mulai</label>
            <input type="date" name="tanggal_mulai" required>
        </div>
        <div class="form-group">
            <label>Tanggal Selesai</label>
            <input type="date" name="tanggal_selesai" required>
        </div>
    </div>

    <div class="form-group">
        <label>Kota Tujuan (pisahkan dengan koma)</label>
        <input type="text" name="kota_tujuan_raw" id="kota_tujuan_raw" placeholder="Jakarta, Manado">
        {{-- diproses jadi array kota_tujuan[] via JS sederhana di app.js --}}
    </div>

    @include('components.pelaksana-table')

    <div class="form-row">
        <div class="form-group">
            <label>Jabatan Penandatangan</label>
            <input type="text" name="jabatan_ttd" required>
        </div>
        <div class="form-group">
            <label>Nama Penandatangan</label>
            <input type="text" name="nama_ttd" required>
        </div>
    </div>

    <button type="submit" class="btn-primary">Simpan & Lanjut</button>
</form>
@endsection
