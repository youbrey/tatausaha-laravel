@extends('layouts.app')

@section('page-title', 'Buat Surat Undangan')

@section('content')
<form method="POST" action="{{ route('surat.undangan.store') }}" class="sips-form">
    @csrf

    <div class="form-group">
        <label>Jenis Undangan</label>
        <select name="jenis_surat" required>
            <option value="UNDANGAN_PARIPURNA">Rapat Paripurna</option>
            <option value="UNDANGAN_BIASA">Rapat AKD</option>
        </select>
    </div>

    <div class="form-group">
        <label>Materi / Agenda Rapat</label>
        <textarea name="materi" rows="2" required></textarea>
    </div>

    <div class="form-row">
        <div class="form-group">
            <label>Tanggal Mulai</label>
            <input type="date" name="tanggal_mulai" required>
        </div>
        <div class="form-group">
            <label>Tanggal Selesai</label>
            <input type="date" name="tanggal_selesai" required>
        </div>
    </div>

    <div class="form-group">
        <label>Tempat</label>
        <input type="text" name="tempat" placeholder="Ruang Rapat Paripurna DPRD">
    </div>

    @include('components.pelaksana-table')

    <div class="form-row">
        <div class="form-group">
            <label>Jabatan Penandatangan</label>
            <input type="text" name="jabatan_ttd" required>
        </div>
        <div class="form-group">
            <label>Nama Penandatangan</label>
            <input type="text" name="nama_ttd" required>
        </div>
    </div>

    <button type="submit" class="btn-primary">Simpan & Lanjut</button>
</form>
@endsection
