@extends('layouts.app')

@section('page-title', 'Preview Undangan')

@section('content')
<div class="preview-card">
    <h3>Nomor Surat: {{ $surat->nomor_surat }}</h3>
    <p><strong>Agenda:</strong> {{ $surat->materi }}</p>
    <p><strong>Tanggal:</strong> {{ $surat->tanggal_mulai->format('d/m/Y') }}</p>
    <p><strong>Penandatangan:</strong> {{ $surat->nama_ttd }} ({{ $surat->jabatan_ttd }})</p>

    <div class="preview-actions">
        <a href="{{ route('surat.undangan.generate', $surat) }}" class="btn-primary">
            Download Undangan (.docx)
        </a>
    </div>
</div>
@endsection
