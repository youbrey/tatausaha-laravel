@extends('layouts.app')

@section('page-title', 'Data Personel')

@section('content')
<div class="personel-grid">
    <div>
        <h3>Personel DPRD</h3>
        <table class="sips-table">
            <thead><tr><th>Nama</th><th>Jabatan</th><th>Kategori</th><th></th></tr></thead>
            <tbody>
                @foreach ($personelDprd as $p)
                <tr>
                    <td>{{ $p->nama }}</td>
                    <td>{{ $p->jabatan }}</td>
                    <td>{{ config('sips.kategori_dprd')[$p->kategori] ?? $p->kategori }}</td>
                    <td>
                        <form method="POST" action="{{ route('personel.dprd.destroy', $p) }}">
                            @csrf @method('DELETE')
                            <button type="submit">Hapus</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <form method="POST" action="{{ route('personel.dprd.store') }}" class="sips-form">
            @csrf
            <input type="text" name="nama" placeholder="Nama" required>
            <input type="text" name="jabatan" placeholder="Jabatan" required>
            <select name="kategori" required>
                @foreach (config('sips.kategori_dprd') as $key => $label)
                    <option value="{{ $key }}">{{ $label }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn-primary">Tambah</button>
        </form>
    </div>

    <div>
        <h3>Personel ASN</h3>
        <table class="sips-table">
            <thead><tr><th>Nama</th><th>NIP</th><th>Pangkat</th><th>Jabatan</th><th></th></tr></thead>
            <tbody>
                @foreach ($personelAsn as $p)
                <tr>
                    <td>{{ $p->nama }}</td>
                    <td>{{ $p->nip }}</td>
                    <td>{{ $p->pangkat }}</td>
                    <td>{{ $p->jabatan }}</td>
                    <td>
                        <form method="POST" action="{{ route('personel.asn.destroy', $p) }}">
                            @csrf @method('DELETE')
                            <button type="submit">Hapus</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <form method="POST" action="{{ route('personel.asn.store') }}" class="sips-form">
            @csrf
            <input type="text" name="nama" placeholder="Nama" required>
            <input type="text" name="nip" placeholder="NIP" required>
            <input type="text" name="pangkat" placeholder="Pangkat" required>
            <input type="text" name="jabatan" placeholder="Jabatan" required>
            <button type="submit" class="btn-primary">Tambah</button>
        </form>
    </div>
</div>
@endsection
