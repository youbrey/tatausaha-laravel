@extends('layouts.app')

@section('page-title', 'Dashboard')

@section('content')
<div class="dashboard-cards">
    <div class="card">
        <span class="card-number">{{ $totalSurat }}</span>
        <span class="card-label">Total Surat</span>
    </div>
    <div class="card">
        <span class="card-number">{{ $suratBulanIni }}</span>
        <span class="card-label">Surat Bulan Ini</span>
    </div>
</div>

<h3>Surat Terbaru</h3>
<table class="sips-table">
    <thead>
        <tr><th>Nomor</th><th>Jenis</th><th>Dibuat oleh</th><th>Tanggal</th><th>Status</th></tr>
    </thead>
    <tbody>
        @foreach ($suratTerbaru as $s)
        <tr>
            <td>{{ $s->nomor_surat }}</td>
            <td>{{ config('sips.jenis_surat')[$s->jenis_surat] ?? $s->jenis_surat }}</td>
            <td>{{ $s->user->name ?? '-' }}</td>
            <td>{{ $s->created_at->format('d/m/Y H:i') }}</td>
            <td>{{ $s->status }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection
