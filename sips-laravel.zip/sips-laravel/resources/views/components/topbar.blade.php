<header class="sips-topbar">
    <div class="topbar-title">@yield('page-title', 'Dashboard')</div>

    <div class="topbar-user">
        @auth
            {{ auth()->user()->name }} ({{ auth()->user()->role }})
            <form method="POST" action="{{ route('logout') }}" style="display:inline">
                @csrf
                <button type="submit">Keluar</button>
            </form>
        @endauth
    </div>
</header>
