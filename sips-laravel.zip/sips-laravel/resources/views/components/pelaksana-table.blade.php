{{-- Komponen reusable: tabel pilih pelaksana DPRD/ASN --}}
{{-- Dipakai di form perjalanan-dinas dan undangan --}}
<div class="form-group">
    <label>Pelaksana DPRD</label>
    <div class="checkbox-list">
        @foreach ($personelDprd as $p)
            <label>
                <input type="checkbox" name="pelaksana_dprd[]" value="{{ $p->id }}">
                {{ $p->nama }} — {{ $p->jabatan }}
            </label>
        @endforeach
    </div>
</div>

<div class="form-group">
    <label>Pelaksana ASN</label>
    <div class="checkbox-list">
        @foreach ($personelAsn as $p)
            <label>
                <input type="checkbox" name="pelaksana_asn[]" value="{{ $p->id }}">
                {{ $p->nama }} — {{ $p->jabatan }}
            </label>
        @endforeach
    </div>
</div>
