<aside class="sips-sidebar">
    <div class="sidebar-brand">SIPS</div>

    <nav class="sidebar-nav">
        <a href="{{ route('dashboard') }}" class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">
            Dashboard
        </a>

        <div class="sidebar-group">
            <span class="sidebar-group-title">Surat Perjalanan Dinas</span>
            <a href="{{ route('surat.perjalanan-dinas.create') }}">Surat Tugas / SPPD</a>
        </div>

        <div class="sidebar-group">
            <span class="sidebar-group-title">Surat Undangan</span>
            <a href="{{ route('surat.undangan.create') }}">Rapat Paripurna / AKD</a>
        </div>

        <a href="{{ route('personel.index') }}" class="{{ request()->routeIs('personel.*') ? 'active' : '' }}">
            Data Personel
        </a>
    </nav>
</aside>
