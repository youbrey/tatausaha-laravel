<?php

namespace App\Http\Controllers\Surat;

use App\Http\Controllers\Controller;
use App\Models\PersonelASN;
use App\Models\PersonelDPRD;
use App\Models\Surat;
use App\Services\DocumentGenerator\SppdGenerator;
use App\Services\DocumentGenerator\SuratTugasGenerator;
use App\Services\NomorSuratService;
use Illuminate\Http\Request;

class PerjalananDinasController extends Controller
{
    public function __construct(private NomorSuratService $nomorService)
    {
    }

    public function create()
    {
        $personelDprd = PersonelDPRD::aktif()->get();
        $personelAsn = PersonelASN::aktif()->get();

        return view('surat.perjalanan-dinas.form', compact('personelDprd', 'personelAsn'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'jenis_surat' => 'required|in:PERJALANAN_DINAS_DPRD,PERJALANAN_DINAS_ASN,PERJALANAN_DINAS_GABUNGAN',
            'dasar_surat_tugas' => 'nullable|string',
            'materi' => 'nullable|string',
            'jenis_perjalanan' => 'nullable|string',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'required|date|after_or_equal:tanggal_mulai',
            'kota_tujuan' => 'required|array|min:1',
            'jabatan_ttd' => 'required|string',
            'nama_ttd' => 'required|string',
            'pelaksana_dprd' => 'nullable|array',
            'pelaksana_asn' => 'nullable|array',
        ]);

        $validated['nomor_surat'] = $this->nomorService->generate($validated['jenis_surat'], 'ST');
        $validated['nomor_spd'] = $this->nomorService->generate($validated['jenis_surat'] . '_SPD', 'SPPD');
        $validated['created_by'] = auth()->id();
        $validated['status'] = 'DRAFT';

        $surat = Surat::create($validated);

        return redirect()
            ->route('surat.perjalanan-dinas.preview', $surat)
            ->with('success', 'Surat tugas berhasil dibuat, nomor: ' . $surat->nomor_surat);
    }

    public function preview(Surat $surat)
    {
        return view('surat.perjalanan-dinas.preview', compact('surat'));
    }

    public function generateSuratTugas(Surat $surat)
    {
        $generator = new SuratTugasGenerator();
        $path = $generator->generate($surat->toArray());

        return response()->download($path)->deleteFileAfterSend();
    }

    public function generateSppd(Surat $surat)
    {
        $generator = new SppdGenerator();
        $path = $generator->generate($surat->toArray());

        return response()->download($path)->deleteFileAfterSend();
    }
}
