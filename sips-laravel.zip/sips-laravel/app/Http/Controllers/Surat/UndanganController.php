<?php

namespace App\Http\Controllers\Surat;

use App\Http\Controllers\Controller;
use App\Models\PersonelASN;
use App\Models\PersonelDPRD;
use App\Models\Surat;
use App\Services\DocumentGenerator\UndanganGenerator;
use App\Services\NomorSuratService;
use Illuminate\Http\Request;

class UndanganController extends Controller
{
    public function __construct(private NomorSuratService $nomorService)
    {
    }

    public function create()
    {
        $personelDprd = PersonelDPRD::aktif()->get();
        $personelAsn = PersonelASN::aktif()->get();

        return view('surat.undangan.form', compact('personelDprd', 'personelAsn'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'jenis_surat' => 'required|in:UNDANGAN_PARIPURNA,UNDANGAN_BIASA',
            'materi' => 'required|string',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'required|date|after_or_equal:tanggal_mulai',
            'kota_tujuan' => 'nullable|array',
            'jabatan_ttd' => 'required|string',
            'nama_ttd' => 'required|string',
            'pelaksana_dprd' => 'nullable|array',
            'pelaksana_asn' => 'nullable|array',
        ]);

        $validated['nomor_surat'] = $this->nomorService->generate($validated['jenis_surat'], 'UND');
        $validated['created_by'] = auth()->id();
        $validated['status'] = 'DRAFT';

        $surat = Surat::create($validated);

        return redirect()
            ->route('surat.undangan.preview', $surat)
            ->with('success', 'Surat undangan berhasil dibuat, nomor: ' . $surat->nomor_surat);
    }

    public function preview(Surat $surat)
    {
        return view('surat.undangan.preview', compact('surat'));
    }

    public function generate(Surat $surat)
    {
        $generator = new UndanganGenerator();
        $path = $generator->generate($surat->toArray());

        return response()->download($path)->deleteFileAfterSend();
    }
}
