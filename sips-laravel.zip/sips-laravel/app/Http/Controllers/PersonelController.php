<?php

namespace App\Http\Controllers;

use App\Models\PersonelASN;
use App\Models\PersonelDPRD;
use Illuminate\Http\Request;

class PersonelController extends Controller
{
    public function index()
    {
        $personelDprd = PersonelDPRD::orderBy('urutan')->get();
        $personelAsn = PersonelASN::orderBy('urutan')->get();

        return view('personel.index', compact('personelDprd', 'personelAsn'));
    }

    public function storeDprd(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string',
            'jabatan' => 'required|string',
            'kategori' => 'required|in:PIMPINAN_DPRD,KOMISI_I,KOMISI_II,KOMISI_III,CUSTOM',
            'urutan' => 'nullable|integer',
        ]);

        PersonelDPRD::create($validated);

        return back()->with('success', 'Personel DPRD ditambahkan.');
    }

    public function storeAsn(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string',
            'nip' => 'required|string|unique:personel_asn,nip',
            'pangkat' => 'required|string',
            'jabatan' => 'required|string',
            'urutan' => 'nullable|integer',
        ]);

        PersonelASN::create($validated);

        return back()->with('success', 'Personel ASN ditambahkan.');
    }

    public function destroyDprd(PersonelDPRD $personel)
    {
        $personel->delete();

        return back()->with('success', 'Personel DPRD dihapus.');
    }

    public function destroyAsn(PersonelASN $personel)
    {
        $personel->delete();

        return back()->with('success', 'Personel ASN dihapus.');
    }
}
