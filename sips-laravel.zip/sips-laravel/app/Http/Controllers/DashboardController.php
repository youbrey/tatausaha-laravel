<?php

namespace App\Http\Controllers;

use App\Models\Surat;

class DashboardController extends Controller
{
    public function index()
    {
        $totalSurat = Surat::count();
        $suratBulanIni = Surat::whereMonth('created_at', now()->month)->count();
        $suratTerbaru = Surat::with('user')->latest()->take(10)->get();

        return view('dashboard.index', compact('totalSurat', 'suratBulanIni', 'suratTerbaru'));
    }
}
