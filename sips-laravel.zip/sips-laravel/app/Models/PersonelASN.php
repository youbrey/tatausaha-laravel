<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonelASN extends Model
{
    protected $table = 'personel_asn';

    protected $fillable = ['nama', 'nip', 'pangkat', 'jabatan', 'aktif', 'urutan'];

    public function scopeAktif($query)
    {
        return $query->where('aktif', true)->orderBy('urutan');
    }
}
