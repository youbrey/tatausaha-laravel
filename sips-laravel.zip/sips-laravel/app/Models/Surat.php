<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Surat extends Model
{
    protected $table = 'surat';

    protected $fillable = [
        'jenis_surat', 'nomor_surat', 'nomor_surat_asn', 'nomor_spd', 'nomor_spd_asn',
        'nomor_pemberitahuan', 'nomor_pemberitahuan_asn', 'dasar_surat_tugas', 'materi',
        'jenis_perjalanan', 'tanggal_mulai', 'tanggal_selesai', 'kota_tujuan', 'mode_dprd',
        'jabatan_ttd', 'nama_ttd', 'pelaksana_dprd', 'pelaksana_asn',
        'file_path', 'file_name', 'file_size', 'status', 'created_by',
    ];

    protected $casts = [
        'kota_tujuan' => 'array',
        'pelaksana_dprd' => 'array',
        'pelaksana_asn' => 'array',
        'tanggal_mulai' => 'datetime',
        'tanggal_selesai' => 'datetime',
        'mode_dprd' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function isPerjalananDinas(): bool
    {
        return str_starts_with($this->jenis_surat, 'PERJALANAN_DINAS');
    }

    public function isUndangan(): bool
    {
        return str_starts_with($this->jenis_surat, 'UNDANGAN');
    }
}
