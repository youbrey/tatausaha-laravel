<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonelDPRD extends Model
{
    protected $table = 'personel_dprd';

    protected $fillable = ['nama', 'jabatan', 'kategori', 'aktif', 'urutan'];

    public function scopeAktif($query)
    {
        return $query->where('aktif', true)->orderBy('urutan');
    }
}
