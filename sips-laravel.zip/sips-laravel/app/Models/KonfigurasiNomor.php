<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KonfigurasiNomor extends Model
{
    protected $table = 'konfigurasi_nomor';

    protected $fillable = ['jenis', 'prefix', 'tahun', 'counter'];
}
