<?php

namespace App\Services\DocumentGenerator;

use PhpOffice\PhpWord\TemplateProcessor;

/**
 * Kelas dasar generator dokumen Word.
 * Tiap jenis surat (SuratTugas, SPPD, Undangan, dst) meng-extend ini
 * dan hanya perlu mengisi mapping placeholder -> data.
 *
 * Master template (.docx) disimpan di storage/app/templates/
 * Placeholder di dalam docx ditulis dengan syntax ${nama_field}
 */
abstract class BaseDocumentGenerator
{
    protected TemplateProcessor $processor;

    protected string $templatePath;

    public function __construct()
    {
        $this->templatePath = storage_path('app/templates/' . $this->templateFile());
        $this->processor = new TemplateProcessor($this->templatePath);
    }

    /** Nama file master template di storage/app/templates/ */
    abstract protected function templateFile(): string;

    /** Mapping data ke placeholder, di-override tiap subclass */
    abstract protected function mapData(array $data): array;

    /** Isi tabel pelaksana / lampiran (klon baris), di-override jika perlu */
    protected function fillTable(array $data): void
    {
        // default: tidak ada tabel dinamis
    }

    public function generate(array $data): string
    {
        foreach ($this->mapData($data) as $key => $value) {
            $this->processor->setValue($key, htmlspecialchars((string) $value));
        }

        $this->fillTable($data);

        $outputName = $this->buildOutputFilename($data);
        $outputPath = storage_path('app/output/' . $outputName);

        $this->processor->saveAs($outputPath);

        return $outputPath;
    }

    protected function buildOutputFilename(array $data): string
    {
        $nomor = str_replace('/', '-', $data['nomor_surat'] ?? 'surat');

        return "{$nomor}_" . now()->format('Ymd_His') . '.docx';
    }
}
