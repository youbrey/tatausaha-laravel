<?php

namespace App\Services\DocumentGenerator;

use InvalidArgumentException;

class DocumentGeneratorFactory
{
    public static function make(string $jenisSurat): BaseDocumentGenerator
    {
        return match (true) {
            str_starts_with($jenisSurat, 'PERJALANAN_DINAS') => new SuratTugasGenerator(),
            str_starts_with($jenisSurat, 'UNDANGAN') => new UndanganGenerator(),
            default => throw new InvalidArgumentException("Generator untuk jenis surat '{$jenisSurat}' belum tersedia."),
        };
    }
}
