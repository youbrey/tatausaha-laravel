<?php

namespace App\Services\DocumentGenerator;

use App\Services\TanggalIndonesiaService;

class UndanganGenerator extends BaseDocumentGenerator
{
    protected function templateFile(): string
    {
        return 'undangan_master.docx';
    }

    protected function mapData(array $data): array
    {
        $tanggal = new TanggalIndonesiaService();

        return [
            'nomor_surat' => $data['nomor_surat'],
            'materi' => $data['materi'] ?? '-',
            'hari_tanggal' => $tanggal->format($data['tanggal_mulai'], true),
            'tempat' => $data['tempat'] ?? ($data['kota_tujuan'][0] ?? '-'),
            'jabatan_ttd' => $data['jabatan_ttd'],
            'nama_ttd' => $data['nama_ttd'],
        ];
    }

    protected function fillTable(array $data): void
    {
        $undangan = array_merge($data['pelaksana_dprd'] ?? [], $data['pelaksana_asn'] ?? []);

        $this->processor->cloneRow('no', count($undangan) ?: 1);

        foreach ($undangan as $i => $orang) {
            $row = $i + 1;
            $this->processor->setValue("no#{$row}", $row);
            $this->processor->setValue("nama_pelaksana#{$row}", $orang['nama'] ?? '');
            $this->processor->setValue("jabatan_pelaksana#{$row}", $orang['jabatan'] ?? '');
        }
    }
}
