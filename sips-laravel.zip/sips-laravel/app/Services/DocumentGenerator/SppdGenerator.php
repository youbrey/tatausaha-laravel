<?php

namespace App\Services\DocumentGenerator;

use App\Services\TanggalIndonesiaService;

class SppdGenerator extends BaseDocumentGenerator
{
    protected function templateFile(): string
    {
        return 'sppd_master.docx';
    }

    protected function mapData(array $data): array
    {
        $tanggal = new TanggalIndonesiaService();

        return [
            'nomor_spd' => $data['nomor_spd'],
            'nomor_surat_tugas' => $data['nomor_surat'],
            'jenis_perjalanan' => $data['jenis_perjalanan'] ?? '-',
            'kota_tujuan' => implode(', ', $data['kota_tujuan'] ?? []),
            'tanggal_berangkat' => $tanggal->format($data['tanggal_mulai']),
            'tanggal_kembali' => $tanggal->format($data['tanggal_selesai']),
            'jabatan_ttd' => $data['jabatan_ttd'],
            'nama_ttd' => $data['nama_ttd'],
        ];
    }

    protected function fillTable(array $data): void
    {
        $pelaksana = array_merge($data['pelaksana_dprd'] ?? [], $data['pelaksana_asn'] ?? []);

        $this->processor->cloneRow('no', count($pelaksana) ?: 1);

        foreach ($pelaksana as $i => $orang) {
            $row = $i + 1;
            $this->processor->setValue("no#{$row}", $row);
            $this->processor->setValue("nama_pelaksana#{$row}", $orang['nama'] ?? '');
            $this->processor->setValue("jabatan_pelaksana#{$row}", $orang['jabatan'] ?? '');
        }
    }
}
