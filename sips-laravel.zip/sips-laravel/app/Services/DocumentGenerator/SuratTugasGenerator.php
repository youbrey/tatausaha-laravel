<?php

namespace App\Services\DocumentGenerator;

use App\Services\TanggalIndonesiaService;

class SuratTugasGenerator extends BaseDocumentGenerator
{
    protected function templateFile(): string
    {
        return 'surat_tugas_master.docx';
    }

    protected function mapData(array $data): array
    {
        $tanggal = new TanggalIndonesiaService();

        return [
            'nomor_surat' => $data['nomor_surat'],
            'dasar_surat_tugas' => $data['dasar_surat_tugas'] ?? '-',
            'materi' => $data['materi'] ?? '-',
            'tanggal_pelaksanaan' => $tanggal->formatRentang($data['tanggal_mulai'], $data['tanggal_selesai']),
            'kota_tujuan' => implode(', ', $data['kota_tujuan'] ?? []),
            'jabatan_ttd' => $data['jabatan_ttd'],
            'nama_ttd' => $data['nama_ttd'],
            'tanggal_surat' => $tanggal->format(now()),
        ];
    }

    protected function fillTable(array $data): void
    {
        $pelaksana = array_merge($data['pelaksana_dprd'] ?? [], $data['pelaksana_asn'] ?? []);

        $this->processor->cloneRow('no', count($pelaksana) ?: 1);

        foreach ($pelaksana as $i => $orang) {
            $row = $i + 1;
            $this->processor->setValue("no#{$row}", $row);
            $this->processor->setValue("nama_pelaksana#{$row}", $orang['nama'] ?? '');
            $this->processor->setValue("jabatan_pelaksana#{$row}", $orang['jabatan'] ?? '');
        }
    }
}
