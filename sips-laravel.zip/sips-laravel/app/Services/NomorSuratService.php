<?php

namespace App\Services;

use App\Models\KonfigurasiNomor;

/**
 * Menangani penomoran surat otomatis per jenis, mirip utils/numbering.py
 * di versi Python. Format umum: {counter}/{prefix}/{tahun}
 */
class NomorSuratService
{
    public function generate(string $jenis, string $prefix): string
    {
        $tahun = now()->year;

        $config = KonfigurasiNomor::firstOrCreate(
            ['jenis' => $jenis],
            ['prefix' => $prefix, 'tahun' => $tahun, 'counter' => 0]
        );

        // Reset counter kalau tahun berganti
        if ($config->tahun !== $tahun) {
            $config->tahun = $tahun;
            $config->counter = 0;
        }

        $config->counter += 1;
        $config->save();

        $nomorUrut = str_pad((string) $config->counter, 3, '0', STR_PAD_LEFT);

        return "{$nomorUrut}/{$config->prefix}/{$tahun}";
    }

    public function peekNext(string $jenis, string $prefix): string
    {
        $tahun = now()->year;
        $config = KonfigurasiNomor::where('jenis', $jenis)->first();
        $counter = $config && $config->tahun === $tahun ? $config->counter + 1 : 1;
        $nomorUrut = str_pad((string) $counter, 3, '0', STR_PAD_LEFT);

        return "{$nomorUrut}/{$prefix}/{$tahun}";
    }
}
