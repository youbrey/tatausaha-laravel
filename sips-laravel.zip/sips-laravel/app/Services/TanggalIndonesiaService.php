<?php

namespace App\Services;

use Carbon\Carbon;

/**
 * Mengubah tanggal ke format Bahasa Indonesia.
 * Mirip utils/tanggal Indonesia di versi Python & lib/utils/tanggal.ts Next.js.
 */
class TanggalIndonesiaService
{
    private const BULAN = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember',
    ];

    private const HARI = [
        'Sunday' => 'Minggu', 'Monday' => 'Senin', 'Tuesday' => 'Selasa',
        'Wednesday' => 'Rabu', 'Thursday' => 'Kamis', 'Friday' => 'Jumat', 'Saturday' => 'Sabtu',
    ];

    public function format(Carbon|string $tanggal, bool $denganHari = false): string
    {
        $tanggal = $tanggal instanceof Carbon ? $tanggal : Carbon::parse($tanggal);

        $hasil = "{$tanggal->day} " . self::BULAN[$tanggal->month] . " {$tanggal->year}";

        if ($denganHari) {
            $hari = self::HARI[$tanggal->format('l')];
            $hasil = "{$hari}, {$hasil}";
        }

        return $hasil;
    }

    public function formatRentang(Carbon|string $mulai, Carbon|string $selesai): string
    {
        $mulai = $mulai instanceof Carbon ? $mulai : Carbon::parse($mulai);
        $selesai = $selesai instanceof Carbon ? $selesai : Carbon::parse($selesai);

        if ($mulai->isSameDay($selesai)) {
            return $this->format($mulai);
        }

        if ($mulai->month === $selesai->month && $mulai->year === $selesai->year) {
            return "{$mulai->day} s.d. {$selesai->day} " . self::BULAN[$selesai->month] . " {$selesai->year}";
        }

        return $this->format($mulai) . ' s.d. ' . $this->format($selesai);
    }
}
