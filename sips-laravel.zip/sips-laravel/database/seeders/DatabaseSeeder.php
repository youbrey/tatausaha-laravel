<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Administrator',
            'email' => 'admin@sips.local',
            'password' => Hash::make('password123'),
            'role' => 'SUPERADMIN',
            'jabatan' => 'Admin Sistem',
        ]);
    }
}
