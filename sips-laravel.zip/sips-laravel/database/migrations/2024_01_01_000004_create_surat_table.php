<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('surat', function (Blueprint $table) {
            $table->id();
            $table->enum('jenis_surat', [
                'PERJALANAN_DINAS_DPRD',
                'PERJALANAN_DINAS_ASN',
                'PERJALANAN_DINAS_GABUNGAN',
                'UNDANGAN_PARIPURNA',
                'UNDANGAN_BIASA',
            ]);
            $table->string('nomor_surat');
            $table->string('nomor_surat_asn')->nullable();
            $table->string('nomor_spd')->nullable();
            $table->string('nomor_spd_asn')->nullable();
            $table->string('nomor_pemberitahuan')->nullable();
            $table->string('nomor_pemberitahuan_asn')->nullable();

            $table->text('dasar_surat_tugas')->nullable();
            $table->text('materi')->nullable();
            $table->string('jenis_perjalanan')->nullable();
            $table->dateTime('tanggal_mulai');
            $table->dateTime('tanggal_selesai');
            $table->json('kota_tujuan')->nullable();
            $table->boolean('mode_dprd')->default(true);

            $table->string('jabatan_ttd');
            $table->string('nama_ttd');

            $table->json('pelaksana_dprd')->nullable();
            $table->json('pelaksana_asn')->nullable();

            $table->string('file_path')->nullable();
            $table->string('file_name')->nullable();
            $table->integer('file_size')->nullable();

            $table->enum('status', ['DRAFT', 'GENERATED', 'SIGNED', 'ARCHIVED'])->default('DRAFT');
            $table->foreignId('created_by')->constrained('users');
            $table->timestamps();

            $table->index(['jenis_surat', 'created_at']);
            $table->index('nomor_surat');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('surat');
    }
};
