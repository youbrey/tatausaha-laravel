<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('personel_dprd', function (Blueprint $table) {
            $table->id();
            $table->string('nama');
            $table->string('jabatan');
            $table->enum('kategori', ['PIMPINAN_DPRD', 'KOMISI_I', 'KOMISI_II', 'KOMISI_III', 'CUSTOM']);
            $table->boolean('aktif')->default(true);
            $table->integer('urutan')->default(0);
            $table->timestamps();

            $table->index('kategori');
            $table->index('aktif');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('personel_dprd');
    }
};
