<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('konfigurasi_nomor', function (Blueprint $table) {
            $table->id();
            $table->string('jenis')->unique();
            $table->string('prefix');
            $table->integer('tahun');
            $table->integer('counter')->default(0);
            $table->timestamps();
        });

        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->string('action');
            $table->string('resource');
            $table->string('resource_id')->nullable();
            $table->json('detail')->nullable();
            $table->string('ip')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('konfigurasi_nomor');
    }
};
